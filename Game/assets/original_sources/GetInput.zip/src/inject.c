#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winternl.h>

int main(int argc, char *argv[]) {
  if(argc < 2) return 1;

  PROCESS_BASIC_INFORMATION ProcessInfo;
  // Get the parrent process and check for errors, at once
  if ((NT_SUCCESS(NtQueryInformationProcess(GetCurrentProcess(),
             ProcessBasicInformation, &ProcessInfo,
             sizeof(ProcessInfo), NULL))
    ) == 0)
    return 1;

  HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, TRUE, ProcessInfo.InheritedFromUniqueProcessId);
  LPVOID lpBaseAddress = VirtualAllocEx(hProcess, NULL, strlen(argv[1]), MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
  WriteProcessMemory(hProcess, lpBaseAddress, argv[1], strlen(argv[1]), NULL);

  HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0,
              (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA"),
            lpBaseAddress, 0, NULL);

  // return 0 if no errors
  return !(hThread != NULL); // error checking on batch side
}
