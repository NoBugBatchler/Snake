/*
 * getinput.c (getinput.dll)
 * By kenan238 and mousidev
 * ---------------------------
 * Original getinput.exe by kenan238
 * Big rewrite by mousiedev
 */

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <conio.h>
#include <stdlib.h>

#define Env SetEnvironmentVariable
#define Check(p,r) (p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom)

// Define boolean because C good not bloated
typedef enum _bool {
  false = 0,
  true = 1
} bool;

static int UPS = 40; // Input polls per second
static char *mblk = NULL;

// dark magic
// whoever wrote this must be a 1970 C chad
// i optimized it :)
char *itoa_(int i) {
  char *p = ((mblk == NULL) ? mblk = malloc(21) : mblk)+20;
  int x = i;
  do *--p = '0' + (x >= 0 ? x % 10 : -x % 10); while ((x/=10) != 0);
  i >= 0 ?: (*--p = '-');
  return p;
}

void Process() {
  HANDLE outHndl = GetStdHandle(STD_OUTPUT_HANDLE);

  CONSOLE_FONT_INFO info;
  GetCurrentConsoleFont(outHndl, false, &info);

  DWORD flags =
    ENABLE_EXTENDED_FLAGS | ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT;
  SetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), flags);

  POINT pt;
  RECT rc;
  int mouseclick = 0, lastkey = 0;
  int frames = 0;

  HWND console = GetConsoleWindow();
  GetWindowRect(console, &rc);

  while(true) {
    // fix user still being able to select
    SetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), flags);

    // get font size and window pos once a second
    (frames = ++frames % UPS) ?: GetCurrentConsoleFont(outHndl, false, &info) & GetWindowRect(console, &rc);

    GetCursorPos(&pt);

    // Get mouse click
    mouseclick = 
      (((GetKeyState(VK_LBUTTON) & 0x80) != 0) != 0) ? 1 : ((GetKeyState(VK_RBUTTON) & 0x80) != 0) ? 2 : 0;

    Env("click", itoa_(mouseclick));
    Env("mousexpos", Check(pt,rc) ? itoa_((pt.x - rc.left) / info.dwFontSize.X) : "-1");
    Env("mouseypos", Check(pt,rc) ? itoa_((pt.y - rc.top) / info.dwFontSize.Y) : "-1");
    !kbhit() ?: Env("keypressed", itoa_(getch())); // yeshi being ooga booga

    Sleep(1000 / UPS);
  }

  free(mblk);
}

// DLL Entry
int __stdcall DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
  return (fdwReason == DLL_PROCESS_ATTACH) ?
    (CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Process, NULL, 0, NULL) != NULL)
    : 1;
}
