GetInput
========

### Table of contents:
* [table of contents](#table-of-contents)
* [credits](#credits)
* [how it works](#how-it-works)
* [features](#features)
* [added variables](#added-variables)
* [file list](#files)
* [license](#license)

### credits
#### by:
* kenan238
* mousiedev

made primairly for yeshi

### how it works
injects dll into its parrent cmd.exe and adds additional functionality

### features:
 * easy to setup in existing batch scripts
 * mouse and keyboard polling
 * fast

### added variables
 * `keypressed` - constains the keycode that was pressed
     - must be cleared manually
 * `click` - mouse click
   * `0`: none
   * `1`: left
   * `2`: right
   - its value is set until mouse gets released
 * `mousexpos`: contains the xpos of the mouse |- these two contain `-1` if out of window
 * `mouseypos`: contains the ypos of the mouse |  measured in `cmd.exe` cells

### files
<details>
  <summary>/doc/</summary>

* `doc.txt` - this document
* `example.bat` - feature rich example
 * can accept arguments:
   * %1 => [number >= 0]  - delay between loops (gets plugged into busy loop)
   * %2 => noinject - don't inject
* `minimal.bat` - very minimal example
</details>

<details>
<summary>/source/</summary>

* `source/` - source code directory
* `inject.c` - inject.dll source code
* `getinput.c` - getinput.dll source code
</details>

<details>
<summary>/</summary>

* `getinput.dat` - the thing that gets injected into cmd (its actually .dll)
* `inject.dll` - renamed .exe so nobody executes it by accident; thats the thing that injects getinput.dat into cmd.exe
 * TAKES GETINPUT'S FILENAME AS AN ARGUMENT!
</details>
<br>

### license
```
 Source code, binaries, sample scripts and documentation (onwards only as 'Distribution')
are (C) by mousiedev and kenan238. All rights reserved.

 You may NOT use, copy or modify or distribute the source code (onwards only as 'Code')
or other parts of the Distribution unless given written permission from owners.

 Code, documentation and sample scripts are included only for demonstrational purposes.

 For permission to copy binaries, documentation or sample scripts,
message 'mousiedev_t#5527' or 'kenan238#6162' on Discord.

 You may NOT alter this statement.
```